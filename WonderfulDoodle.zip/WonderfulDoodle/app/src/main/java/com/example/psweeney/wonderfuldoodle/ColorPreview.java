package com.example.psweeney.wonderfuldoodle;

import android.content.Context;
import android.view.View;

/**
 * Created by psweeney on 3/22/16.
 */
public class ColorPreview extends View {

    public ColorPreview(Context context){
        super(context);
    }
}
